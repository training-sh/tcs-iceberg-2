# Olist Seller Operations Platform

Start with [CAPSTONE.md](CAPSTONE.md). It contains the direct steps and hints for an approximately four-to-five-hour deployment and administration exercise.

- [Environment](ENVIRONMENT.md)
- [Data and result definitions](DATA_NOTES.md)
- [Assessment](ASSESSMENT.md)
- [Reference commands and answers](SOLUTION.md)
- [Expected results](EXPECTED_RESULTS.md)
- [Cleanup](CLEANUP.md)

The assignment archive contains the data, standalone programs, manifests and queries. The separate reference archive adds complete commands, expected rows and troubleshooting answers. Neither archive depends on external deployment scripts or project-package imports.
