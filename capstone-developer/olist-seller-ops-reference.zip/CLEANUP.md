# Cleanup

Save the required evidence before deleting the capstone project. Delete only its namespace; do not remove `bigdata`, platform namespaces, images or cluster configuration.

```bash
oc delete project olist-seller-ops --wait=false
oc get namespace olist-seller-ops
```

Normal completion is `NotFound` for the namespace. Its workloads and PVCs are removed with it.

## When deletion remains Terminating

Inspect the reason rather than changing platform monitoring:

```bash
oc get namespace olist-seller-ops -o yaml
oc -n olist-seller-ops get pods,pvc,deploy,sts,jobs,cm,secrets,roles,rolebindings,sa,services,routes,endpointslices -o name
```

The reference cluster has a registered but stopped Metrics API. This can block namespace discovery even after all stored objects are removed. Leave that API and its permissions unchanged.

Finalization is appropriate only when the namespace conditions confirm all of the following: `NamespaceContentRemaining=False`, `NamespaceDeletionContentFailure=False`, `NamespaceFinalizersRemaining=False` and `NamespaceDeletionGroupVersionParsingFailure=False`; the resource listing is empty; and the only discovery failure is `metrics.k8s.io/v1beta1`. Metrics observations are transient, not stored namespace objects.

For that exact condition, save the namespace JSON, change only `spec.finalizers` to an empty array, and submit it to the namespace finalization endpoint:

```bash
oc get namespace olist-seller-ops -o json > working/namespace-finalize.json
```

After the single field has been changed:

```bash
oc replace --raw /api/v1/namespaces/olist-seller-ops/finalize -f working/namespace-finalize.json
oc get namespace olist-seller-ops
```

Do not use this fallback if content remains, an application finalizer remains, or another API group cannot be discovered. It is a namespace cleanup procedure, not a platform repair task.
