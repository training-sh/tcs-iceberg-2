# Data and results

The supplied sample contains 3,095 sellers, 3,000 orders and 3,379 order-item rows. Orders are selected by a reproducible hash of `order_id`; all associated items and all sellers are retained. File sizes, hashes and row counts are in `data/manifest.json`.

Use the original relationships:

- `sellers.seller_id = order_items.seller_id`
- `order_items.order_id = orders.order_id`

## Seller activity

`seller_activity` has one row for every seller, including sellers with no sampled orders. It contains seller ID/state, distinct orders handled, item rows, merchandise value excluding freight, delivered/canceled/other distinct order counts, and on-time/late/missing carrier-handoff item counts.

Shipping performance compares item-level `shipping_limit_date` with order-level `order_delivered_carrier_date`. Equality is on time. A missing carrier timestamp is counted separately. The order-level timestamp is an operational proxy; it does not prove an individual seller's exact dispatch time.

Orders involving several sellers count once for each seller. Fulfillment counts are distinct orders per seller; shipping counts are item rows.

## Geography

`seller_geography` contains seller state, seller count and order-item rows. There are 23 state rows in the supplied sample.

## Expected totals

| Measure | Value |
|---|---:|
| Sellers | 3,095 |
| Input orders | 3,000 |
| Item rows | 3,379 |
| Seller-order pairs | 3,007 |
| Merchandise value | 390,764.28 |
| Delivered seller-order pairs | 2,947 |
| Canceled seller-order pairs | 11 |
| Other seller-order pairs | 49 |
| On-time handoff items | 3,022 |
| Late handoff items | 321 |
| Missing handoff items | 36 |

Both business tables are published to Hive/HDFS and Polaris/Iceberg/S3. The verification Job compares every row from both catalogs with independently calculated results from the CSV bytes. A successful run records `SELLER_OPS_PASS`, a report in the exporter and a durable verification table in Polaris/S3.

The processing programs are standalone files. They use the Python and Spark libraries already present in the supplied image; they do not import other project files or require package installation.

Source: [Brazilian E-Commerce Public Dataset by Olist](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce). Retain its CC BY-NC-SA 4.0 attribution and terms when distributing this subset.
