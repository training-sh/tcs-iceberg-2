# Olist Seller Operations Platform

Deploy a platform that helps Olist's seller operations team check seller activity, merchandise value, fulfillment status and shipping deadlines. Use Spark to process the supplied data, Hive/Hadoop and Polaris/S3 to store the results, Trino to check them, and Loki, Prometheus and Grafana to observe the platform.

Allow about **4-5 hours**. Data, standalone programs, SQL and manifests are ready. Your work is deployment and administration. Use your existing CRC/OpenShift cluster and its supplied images. Do not build images, write application code, change platform monitoring or alter registry permissions.

Read `DATA_NOTES.md` for the output definitions and `ASSESSMENT.md` for marking. Save text evidence as you work. Submit `ParticipantID_Olist_Seller_Ops.zip` containing final non-secret manifests, blank credential templates, results, logs and a short report. Screenshots may supplement text evidence. Exclude passwords, tokens, supplied programs and source data from the submission. Keep the project until the evidence has been checked; cleanup is covered separately.

## Work to complete

### 1. Prepare the project

Confirm that CRC is running, authenticate and check node readiness and storage provisioning. Create and select `olist-seller-ops`. Use `00-project.yaml` to create its workload ServiceAccount.

**Hint:** check your identity and active project before deploying anything.

### 2. Prepare configuration and data

Check the CSV hashes against `data/manifest.json`. Make a private working copy of `02-secret-template.yaml` and fill every placeholder. Use alphanumeric lab secrets and keep database and Polaris usernames as `team`. Match the database passwords, the S3 keys and identity JSON, and the Polaris client secret and bootstrap text. Create `grafana-login` with a private `password` key.

Apply `03-application.yaml`. Create `seller-input-main` from the sellers and items CSVs and `seller-input-orders` from the orders CSV, preserving the original filenames as keys.

**Hint:** settings use ConfigMaps; credentials use Secrets. Keep the input files split across the two ConfigMaps.

### 3. Deploy storage and databases

Deploy `10-seaweedfs.yaml`, `11-postgresql.yaml` and `12-mysql.yaml`. Confirm that all three server pods are Ready and their PVCs are Bound.

**Hint:** inspect events when a pod does not become Ready.

### 4. Prepare Polaris

Run `20-polaris-bootstrap.yaml` and wait for completion. Deploy `21-polaris.yaml` and wait for readiness. Run `22-polaris-catalog.yaml` and confirm `POLARIS_CATALOG_READY`.

**Hint:** bootstrap, server startup and catalog configuration must happen in that order.

### 5. Prepare Hadoop and Hive

Deploy `30-hdfs.yaml` and confirm one registered DataNode. Prepare HDFS directories `/user/hive/warehouse`, `/olist` and `/tmp/hive`; use shared temporary-directory mode `1777` for `/tmp/hive`.

Run `31-hive-schema.yaml` to completion, then deploy `32-hive.yaml` and confirm Hive Metastore readiness. Leave HiveServer2 stopped for now.

**Hint:** run the HDFS client inside the NameNode container. Finish schema initialization before starting the Metastore.

### 6. Upload the inputs and start Spark

Run `69-input-job.yaml`. Confirm completion and three `INPUT_UPLOADED` messages. Deploy `40-spark.yaml` and confirm one worker registered with the master.

**Hint:** the upload Job also prepares Spark's S3 event-log directory. A Ready worker pod still needs to register with the master.

### 7. Run and verify the supplied workload

Deploy `60-metrics.yaml` and `61-logging.yaml`; wait for the exporter, Loki and collector to be Ready. Run `70-seller-job.yaml`. Record the run ID from `SELLER_COMPUTE_PASS` after the Job completes.

Deploy `50-trino.yaml` and wait for readiness. Copy `71-verify-job.yaml` into your working area, replace its `RUN_ID` placeholder with that run ID and run it. Confirm completion and `SELLER_OPS_PASS`.

**Hint:** the first Job publishes the results. The second checks every row through Trino against the supplied input bytes. Both must succeed.

### 8. Check the business results

Put the successful run ID into a working copy of `queries/validation.sql` and execute the supplied queries through Trino. Compare the output with `data/expected-summary.json`. Check both catalogs, the geography results and the physical output locations.

**Hint:** expect zero differing rows between the catalogs. Seller-order totals count an order once for each seller involved.

### 9. Scale and collect logs

Stop the completed Trino coordinator, retaining its PVC. Record the worker count, scale from one to two workers and confirm both readiness and registration. Save master, worker and Job logs.

**Hint:** replica count and Spark registration are separate checks. Explain the resource limit if a second worker cannot be scheduled.

### 10. Check Hive access and release batch resources

Start HiveServer2, run `queries/hive_metadata.sql` with its supplied Beeline client and stop it again. Stop the workers, Hive Metastore, NameNode and DataNode after saving their evidence. Retain all PVCs and keep the Spark master running. Restart Trino for metrics observation.

**Hint:** this controlled shutdown frees memory. HDFS/Hive queries are intentionally unavailable until those servers are restarted; the stored results are retained.

### 11. Observe the platform and resolve the assigned fault

Deploy `62-prometheus.yaml`, `63-grafana.yaml` and `64-routes.yaml`. Open Spark UI and authenticated Grafana. Find the successful run in Loki, check scrape health and record job success, processing seconds, input items and output rows.

Investigate the single assigned connectivity fault. Record the symptom, investigation, root cause, correction and verified recovery.

**Hint:** trace Route, Service and selected pods. Use Service forwarding if Route access is unavailable.

### 12. Check the Metrics API

Check whether the Kubernetes Metrics API is registered and available. Collect node and pod CPU/memory readings when available. Otherwise, record the API condition and explain why the application metrics still work. Leave platform monitoring and permissions unchanged.

**Hint:** a registered API can be unavailable when its backing Service has no ready endpoints.
