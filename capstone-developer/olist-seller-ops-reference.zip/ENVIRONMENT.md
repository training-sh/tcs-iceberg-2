# Environment

Use the existing CRC/OpenShift installation on the supplied training VM. The manifests reuse the course images; no image builds or new cluster installation are part of the exercise.

Before beginning, confirm cluster access, a Ready node, a working default StorageClass and availability of the image references listed in `IMAGES.json`. Private image references must already be accessible through the training environment. Do not add registry grants or change security policies to work around a different VM image.

The workflow limits memory use by finishing Spark publishing before starting Trino verification. It then checks scaling and Hive access, saves evidence, and stops completed batch services before bringing up the dashboard. PVCs are retained until cleanup. Follow that order even if the VM has spare capacity.

The reference cluster has an unavailable Kubernetes Metrics API. Application metrics use the supplied exporter and Prometheus, so processing and dashboard checks do not depend on that API. The final task is to inspect and explain its availability, leaving platform configuration unchanged.

CRC may report `OKD: Starting` while the existing API is reachable and its node is Ready because pre-existing operator checks are incomplete. Record the operator conditions; do not change platform services to make the summary label disappear.

Browser access uses the Route hosts created by the cluster. Service forwarding is provided as an alternative. Use the VM's own terminal and browser; `localhost` in the reference commands refers to that VM.
