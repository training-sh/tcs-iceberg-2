# Assessment

| Area | Marks | Full credit | Partial credit | Evidence |
|---|---:|---|---|---|
| Cluster access and project | 10 | Identity/version, Ready node, storage and correct active project verified | 5–8 for a missing check; 1–4 for access without correct project use | Access and project records |
| Configuration and credentials | 15 | Settings and all Secret references match; input ConfigMaps are correct; evidence contains no credentials | 8–12 for a minor corrected mismatch; 1–7 for incomplete configuration | Sanitized manifests and reference/key checks |
| Deployment and storage | 15 | Required services verified Ready, PVCs Bound, initialization Jobs complete and DataNode registered; controlled shutdown recorded | 8–12 for one incomplete component with a sound diagnosis; 1–7 for a partial platform | Pod/PVC/Job status and dependency checks |
| Networking and access | 10 | Services select the right pods; Spark and authenticated Grafana are accessible; Pod/Service/Route distinction is understood | 5–8 for demonstrated forwarding with a documented Route limit; 1–4 for pod-only access | Services, Routes, endpoints and access results |
| Processing and validation | 15 | Both supplied Jobs succeed; correct business totals, both outputs and zero cross-catalog differences; physical storage checked | 8–12 for successful processing with incomplete result evidence; 1–7 for a diagnosed incomplete run | Run ID, success logs, SQL results and storage checks |
| Scaling | 10 | One-to-two desired/Ready workers and registration verified; capacity effect explained | 6–8 for correct scaling and proven resource limit; 1–5 for replica counts without registration | Before/after counts and Spark registration |
| Logs and metrics | 10 | Relevant logs available directly and in Loki; dashboard values and scrape health interpreted; Metrics API availability checked correctly | 5–8 for one missing observation; 1–4 for pod logs only | Log queries, dashboard readings, targets and API condition |
| Diagnosis and recovery | 10 | Symptom, investigation, root cause, safe correction and verified recovery | 5–8 for correct recovery with weak investigation; 1–4 for symptom only | Five-part fault account |
| Submission and explanation | 5 | Organized evidence, concise explanation and clean credential templates | 2–4 for omissions; 1 for screenshots without supporting text | Archive and report |
| **Total** | **100** | | | |

A documented unavailable Metrics API does not lose marks when the condition is identified correctly and application metrics are verified. A proven scheduling limit can earn scaling credit when the desired configuration and diagnosis are correct. Do not claim successful execution where only manifests or screenshots are available.

Common errors include using the wrong project, inconsistent Secret keys, starting consumers before initialization completes, treating Running as Ready, confusing item rows with distinct orders, checking only output counts, and assuming replica count proves Spark registration. Credential values must be removed from evidence and any exposed value replaced privately.
