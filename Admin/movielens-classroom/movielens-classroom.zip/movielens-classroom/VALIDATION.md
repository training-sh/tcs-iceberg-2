# Validation

The supplied walkthrough has been exercised from an independently extracted checkout, including a directory containing a space.

Verified execution paths:

- Dataset download with archive and file checksum validation.
- Prerequisite checks, scoped MySQL preparation and Kubernetes file publication.
- Four individual Spark stage submissions.
- Serial `run-all.sh` replay.
- Airflow DAG publication, discovery, four-task execution and automatic pausing.
- Independent CSV reference verification after each complete execution path.

Expected results: 9,742 movies, 100,836 ratings, 20 genre summaries and 4,110 daily summaries. Movie and daily rating counts each reconcile to the complete ratings input. Every movie's count, average and distinct-user count, plus every daily and genre rating count, matched both Iceberg and MySQL. JDBC staging values were checked before report publication.

The input contract is `~/data/movielens-small`; `publish.sh` copies it into the shared Kubernetes volume before Spark or Airflow execution. Airflow coordinates the Jobs; Spark drivers read the copied dataset from that volume.

A transient Airflow heartbeat delay detected during verification led to a bounded health wait in preflight. Persistent unhealthy status still stops the exercise. No platform restart is performed by the exercise.

The deployment commands and archive layout have been checked. A published GitHub download must be checked against the actual release URL once available.
